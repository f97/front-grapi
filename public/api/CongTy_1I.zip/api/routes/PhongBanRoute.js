// Dependencies
const express = require('express');
const router = express.Router();
const PhongBanController = require('./../controllers/PhongBanController');

// Enable CORS
router.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", 
    "Origin, X-Requested-With, Content-Type, Accept, X-Access-Token, X-Key");
  next();
});

/**
 * @typedef PhongBan
 * @property {integer} pbID.required
 * @property {string} tenPB.required
 */

/**
 * @route GET /PhongBan
 * @group PhongBan
 * @returns {Array.<PhongBan>} get all PhongBan
 */

// GET '/PhongBan' Route to get all PhongBan
router.get('/', (req, res, next) => {
  PhongBanController.getAllPhongBan((err, success) => {
    if(err)
      res.status(500).json({err: err, data: null});
    else
      res.status(200).json({err: null, data: success});
  });
});

/**
 * @route GET /PhongBan/{PhongBanId}
 * @group PhongBan
 * @param {string} PhongBan.path.required 
 * @returns {Array.<PhongBan>} get all PhongBan
 */

// GET '/PhongBan/:PhongBanId' Route to get a particular PhongBan
router.get('/:PhongBanId', (req, res, next) => {
  PhongBanController.getPhongBan(req.params.PhongBanId, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route POST /PhongBan
 * @group PhongBan
 * @param {PhongBan.model} PhongBan.body.required
 * @returns {Array.<PhongBan>} post a  PhongBan
 */

// POST '/PhongBan' Route to add new PhongBan
router.post('/', (req, res, next) => {
  PhongBanController.addPhongBan(req.body, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route PUT /PhongBan/{PhongBanId}
 * @group PhongBan
 * @param {string} PhongBanId.path.required 
 * @param {PhongBan.model} PhongBan.body.required
 * @returns {Array.<PhongBan>} get one PhongBan
 */

// PUT '/PhongBan/:PhongBanId' Route to modify PhongBan
router.put('/:PhongBanId', (req, res, next) => {
  PhongBanController.modifyPhongBan(req.params.PhongBanId, req.body, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route DELETE /PhongBan/{PhongBanId}
 * @group PhongBan
 * @param {string} PhongBanId.path.required 
 * @returns {Array.<PhongBan>} get one {PhongBan
 */

// DELETE '/PhongBan/:PhongBanId' Route to delete PhongBan
router.delete('/:PhongBanId', (req, res, next) => {
  PhongBanController.deletePhongBan(req.params.PhongBanId, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  })
});

module.exports = router;
    