// Dependencies
const { PhongBan } = require('./../models/PhongBanModel');
const { ObjectId } = require('mongodb');

// Get All PhongBan
const getAllPhongBan = callback => {
  PhongBan.find({}, (err, success) => {
    return callback(err, success);
  })
}

// Get A Particular PhongBan
const getPhongBan = (PhongBanId, callback) => {
  if(!ObjectId.isValid(PhongBanId))
    return callback('Invalid PhongBan Id', 400, null);
  
  PhongBan.findOne({_id: PhongBanId}, (err, data) => {
    if(err)
      return callback(err, 500, null);
    else if(!data)
      return callback('PhongBan Not Found', 404, null);
    else
      return callback(null, 200, data);
  });
}

// Add a PhongBan
const addPhongBan = (data, callback) => {
  let PhongBan = new PhongBan(data);

  PhongBan.save((err, success) => {
    if(err)
      return callback(err, 500, null);
    else
      return callback(null, 200, success);
  });
}

// Modify a PhongBan
const modifyPhongBan = (PhongBanId, data, callback) => {
  if(!ObjectId.isValid(PhongBanId))
    return callback('Invalid PhongBan Id', 400, null);
  
  PhongBan.findOne({_id: PhongBanId}, (err, success) => {
    if(err)
      return callback(err, 500, null);
    else if(!success)
      return callback('PhongBan Not Found', 404, null);
    else{
      PhongBan.update({_id: PhongBanId}, data, (err, success) => {
        if(err)
          return callback(err, 500, null);
        else
          return callback(null, 200, success);
      });
    }
  });
}

// Delete a PhongBan
const deletePhongBan = (PhongBanId, callback) => {
  if(!ObjectId.isValid(PhongBanId))
    return callback('Invalid PhongBan Id', 400, null);
  
  PhongBan.findOne({_id: PhongBanId}, (err, success) => {
    if(err)
      return callback(err, 500, null);
    else if(!success)
      return callback('PhongBan Not Found', 404, null);
    else{
      PhongBan.remove({_id: PhongBanId}, (err, success) => {
        if(err)
          return callback(err, 500, null);
        else
          return callback(null, 200, success);
      })
    }
  })
}

module.exports = {
  getAllPhongBan,
  getPhongBan,
  addPhongBan,
  modifyPhongBan,
  deletePhongBan
}
    