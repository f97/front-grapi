// Dependencies
const mongoose = require('mongoose');

const nhanvienSchema = new mongoose.Schema({
 nvID: {
    type: Number,
    required: true,
  },
 hoten: {
    type: String,
    required: true,
  },
 gioitinh: {
    type: String,
    required: true,
  },
 luong: {
    type: String,
    required: true,
  },
 pbID: {
    type: Number,
    required: true,
  },
 createdAt: {
    type: Date,
    default: Date.now
  }
});
module.exports = {
  Nhanvien : mongoose.model('Nhanvien', nhanvienSchema),
}
    