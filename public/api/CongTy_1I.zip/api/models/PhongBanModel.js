// Dependencies
const mongoose = require('mongoose');

const PhongBanSchema = new mongoose.Schema({
 pbID: {
    type: Number,
    required: true,
  },
 tenPB: {
    type: String,
    required: true,
  },
 createdAt: {
    type: Date,
    default: Date.now
  }
});
module.exports = {
  PhongBan : mongoose.model('PhongBan', PhongBanSchema),
}
    