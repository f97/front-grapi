// Dependencies
const express = require('express');
const router = express.Router();
const nhanvienController = require('./../controllers/nhanvienController');

// Enable CORS
router.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", 
    "Origin, X-Requested-With, Content-Type, Accept, X-Access-Token, X-Key");
  next();
});

/**
 * @typedef Nhanvien
 * @property {integer} nvID.required
 * @property {string} hoten.required
 * @property {string} gioitinh.required
 * @property {string} luong.required
 * @property {integer} pbID.required
 */

/**
 * @route GET /nhanvien
 * @group Nhanvien
 * @returns {Array.<Nhanvien>} get all nhanvien
 */

// GET '/nhanvien' Route to get all nhanvien
router.get('/', (req, res, next) => {
  nhanvienController.getAllNhanvien((err, success) => {
    if(err)
      res.status(500).json({err: err, data: null});
    else
      res.status(200).json({err: null, data: success});
  });
});

/**
 * @route GET /nhanvien/{nhanvienId}
 * @group Nhanvien
 * @param {string} nhanvien.path.required 
 * @returns {Array.<Nhanvien>} get all nhanvien
 */

// GET '/nhanvien/:nhanvienId' Route to get a particular nhanvien
router.get('/:nhanvienId', (req, res, next) => {
  nhanvienController.getNhanvien(req.params.nhanvienId, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route POST /nhanvien
 * @group Nhanvien
 * @param {Nhanvien.model} nhanvien.body.required
 * @returns {Array.<Nhanvien>} post a  nhanvien
 */

// POST '/nhanvien' Route to add new nhanvien
router.post('/', (req, res, next) => {
  nhanvienController.addNhanvien(req.body, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route PUT /nhanvien/{nhanvienId}
 * @group Nhanvien
 * @param {string} nhanvienId.path.required 
 * @param {Nhanvien.model} nhanvien.body.required
 * @returns {Array.<Nhanvien>} get one nhanvien
 */

// PUT '/nhanvien/:nhanvienId' Route to modify nhanvien
router.put('/:nhanvienId', (req, res, next) => {
  nhanvienController.modifyNhanvien(req.params.nhanvienId, req.body, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route DELETE /nhanvien/{nhanvienId}
 * @group Nhanvien
 * @param {string} nhanvienId.path.required 
 * @returns {Array.<Nhanvien>} get one {nhanvien
 */

// DELETE '/nhanvien/:nhanvienId' Route to delete nhanvien
router.delete('/:nhanvienId', (req, res, next) => {
  nhanvienController.deleteNhanvien(req.params.nhanvienId, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  })
});

module.exports = router;
    