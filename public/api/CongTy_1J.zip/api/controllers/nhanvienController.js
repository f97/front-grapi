// Dependencies
const { Nhanvien } = require('./../models/nhanvienModel');
const { ObjectId } = require('mongodb');

// Get All nhanvien
const getAllNhanvien = callback => {
  Nhanvien.find({}, (err, success) => {
    return callback(err, success);
  })
}

// Get A Particular nhanvien
const getNhanvien = (nhanvienId, callback) => {
  if(!ObjectId.isValid(nhanvienId))
    return callback('Invalid nhanvien Id', 400, null);
  
  Nhanvien.findOne({_id: nhanvienId}, (err, data) => {
    if(err)
      return callback(err, 500, null);
    else if(!data)
      return callback('Nhanvien Not Found', 404, null);
    else
      return callback(null, 200, data);
  });
}

// Add a nhanvien
const addNhanvien = (data, callback) => {
  let nhanvien = new Nhanvien(data);

  nhanvien.save((err, success) => {
    if(err)
      return callback(err, 500, null);
    else
      return callback(null, 200, success);
  });
}

// Modify a nhanvien
const modifyNhanvien = (nhanvienId, data, callback) => {
  if(!ObjectId.isValid(nhanvienId))
    return callback('Invalid Nhanvien Id', 400, null);
  
  Nhanvien.findOne({_id: nhanvienId}, (err, success) => {
    if(err)
      return callback(err, 500, null);
    else if(!success)
      return callback('Nhanvien Not Found', 404, null);
    else{
      Nhanvien.update({_id: nhanvienId}, data, (err, success) => {
        if(err)
          return callback(err, 500, null);
        else
          return callback(null, 200, success);
      });
    }
  });
}

// Delete a nhanvien
const deleteNhanvien = (nhanvienId, callback) => {
  if(!ObjectId.isValid(nhanvienId))
    return callback('Invalid Nhanvien Id', 400, null);
  
  Nhanvien.findOne({_id: nhanvienId}, (err, success) => {
    if(err)
      return callback(err, 500, null);
    else if(!success)
      return callback('Nhanvien Not Found', 404, null);
    else{
      Nhanvien.remove({_id: nhanvienId}, (err, success) => {
        if(err)
          return callback(err, 500, null);
        else
          return callback(null, 200, success);
      })
    }
  })
}

module.exports = {
  getAllNhanvien,
  getNhanvien,
  addNhanvien,
  modifyNhanvien,
  deleteNhanvien
}
    