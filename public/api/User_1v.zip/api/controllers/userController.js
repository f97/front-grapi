// Dependencies
const { User } = require('./../models/userModel');
const { ObjectId } = require('mongodb');

// Get All user
const getAllUser = callback => {
  User.find({}, (err, success) => {
    return callback(err, success);
  })
}

// Get A Particular user
const getUser = (userId, callback) => {
  if(!ObjectId.isValid(userId))
    return callback('Invalid user Id', 400, null);
  
  User.findOne({_id: userId}, (err, data) => {
    if(err)
      return callback(err, 500, null);
    else if(!data)
      return callback('User Not Found', 404, null);
    else
      return callback(null, 200, data);
  });
}

// Add a user
const addUser = (data, callback) => {
  let user = new User(data);

  user.save((err, success) => {
    if(err)
      return callback(err, 500, null);
    else
      return callback(null, 200, success);
  });
}

// Modify a user
const modifyUser = (userId, data, callback) => {
  if(!ObjectId.isValid(userId))
    return callback('Invalid User Id', 400, null);
  
  User.findOne({_id: userId}, (err, success) => {
    if(err)
      return callback(err, 500, null);
    else if(!success)
      return callback('User Not Found', 404, null);
    else{
      User.update({_id: userId}, data, (err, success) => {
        if(err)
          return callback(err, 500, null);
        else
          return callback(null, 200, success);
      });
    }
  });
}

// Delete a user
const deleteUser = (userId, callback) => {
  if(!ObjectId.isValid(userId))
    return callback('Invalid User Id', 400, null);
  
  User.findOne({_id: userId}, (err, success) => {
    if(err)
      return callback(err, 500, null);
    else if(!success)
      return callback('User Not Found', 404, null);
    else{
      User.remove({_id: userId}, (err, success) => {
        if(err)
          return callback(err, 500, null);
        else
          return callback(null, 200, success);
      })
    }
  })
}

module.exports = {
  getAllUser,
  getUser,
  addUser,
  modifyUser,
  deleteUser
}
    