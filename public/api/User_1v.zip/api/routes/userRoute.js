// Dependencies
const express = require('express');
const router = express.Router();
const userController = require('./../controllers/userController');

// Enable CORS
router.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", 
    "Origin, X-Requested-With, Content-Type, Accept, X-Access-Token, X-Key");
  next();
});

/**
 * @typedef User
 * @property {string} name.required
 * @property {integer} age.required
 */

/**
 * @route GET /user
 * @group User
 * @returns {Array.<User>} get all user
 */

// GET '/user' Route to get all user
router.get('/', (req, res, next) => {
  userController.getAllUser((err, success) => {
    if(err)
      res.status(500).json({err: err, data: null});
    else
      res.status(200).json({err: null, data: success});
  });
});

/**
 * @route GET /user/{userId}
 * @group User
 * @param {string} user.path.required 
 * @returns {Array.<User>} get all user
 */

// GET '/user/:userId' Route to get a particular user
router.get('/:userId', (req, res, next) => {
  userController.getUser(req.params.userId, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route POST /user
 * @group User
 * @param {User.model} user.body.required
 * @returns {Array.<User>} post a  user
 */

// POST '/user' Route to add new user
router.post('/', (req, res, next) => {
  userController.addUser(req.body, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route PUT /user/{userId}
 * @group User
 * @param {string} userId.path.required 
 * @param {User.model} user.body.required
 * @returns {Array.<User>} get one user
 */

// PUT '/user/:userId' Route to modify user
router.put('/:userId', (req, res, next) => {
  userController.modifyUser(req.params.userId, req.body, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  });
});

/**
 * @route DELETE /user/{userId}
 * @group User
 * @param {string} userId.path.required 
 * @returns {Array.<User>} get one {user
 */

// DELETE '/user/:userId' Route to delete user
router.delete('/:userId', (req, res, next) => {
  userController.deleteUser(req.params.userId, (err, status, data) => {
    res.status(status).json({err: err, data: data});
  })
});

module.exports = router;
    